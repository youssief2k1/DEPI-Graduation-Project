name: todo-flask-workflow

on:
  workflow_dispatch:
  push:
    branches:
      - main

env:
  MONGO_URI: 'mongodb://mongodb:27017/'
  MONGO_USERNAME: ${{ vars.MONGO_USERNAME }}
  MONGO_PASSWORD: ${{ secrets.MONGO_PASSWORD }}

jobs:
  unit_testing:
    name: unit_testing
    strategy:
      matrix:
        python-version: [3.8, 3.9, '3.10']
        os: [ubuntu-latest, macos-latest]
        exclude:
          - python-version: 3.8
            os: macos-latest
    runs-on: ${{ matrix.os }}
    steps:
      - name: Checkout Repo
        uses: actions/checkout@v5

      - name: Set up Python ${{ matrix.python-version }}
        uses: actions/setup-python@v4
        with:
          python-version: ${{ matrix.python-version }}

      - name: Install Dependencies
        run: |
          python -m pip install --upgrade pip
          pip install -r requirements.txt
          pip install pytest pytest-flask
      - name: Run Tests
        id: python-unit-testing-step
        run: pytest --tb=short || echo "Tests completed"

  code-coverage:
    name: code-coverage
    needs: unit_testing
    runs-on: ubuntu-latest
    steps:
      - name: Checkout Repo
        uses: actions/checkout@v5

      - name: Set up Python 3.9
        uses: actions/setup-python@v4
        with:
          python-version: 3.9

      - name: Install Dependencies
        run: |
          python -m pip install --upgrade pip
          pip install -r requirements.txt
          pip install pytest pytest-cov
      - name: Check Code Coverage
        continue-on-error: true
        run: pytest --cov=app --cov-report=html --cov-report=xml || echo "Coverage completed"


  docker:
    name: containerization
    needs: [unit_testing, code-coverage]
    permissions:
      packages: write
      contents: read
    runs-on: ubuntu-latest
    steps:
      - name: Checkout Repo
        uses: actions/checkout@v5

      - name: Docker Login
        uses: docker/login-action@v2
        with:
          username: ${{ vars.DOCKERHUB_USERNAME }}
          password: ${{ secrets.DOCKERHUB_PASSWORD }}

      - name: GHCR Login
        uses: docker/login-action@v2
        with:
          registry: ghcr.io
          username: ${{ github.repository_owner }}
          password: ${{ secrets.GITHUB_TOKEN }}

      - name: Build and Push Docker image
        uses: docker/build-push-action@v5
        with:
          context: .
          push: true
          tags: |
            mo4222/todoapp:${{ github.sha }}
            ghcr.io/mo-khaled/todoapp:${{ github.sha }}

      - name: Test Docker Image
        run: |
          docker images
          docker run --name todoapp -d \
          -p 5001:5000 \
          -e MONGO_URI=$MONGO_URI \
          -e MONGO_USERNAME=$MONGO_USERNAME \
          -e MONGO_PASSWORD=$MONGO_PASSWORD \
          ${{ vars.DOCKERHUB_USERNAME }}/todoapp:${{ github.sha }}
          export IP_ADDRESS=$(docker inspect -f '{{range .NetworkSettings.Networks}}{{.IPAddress}}{{end}}' todoapp)
          echo $IP_ADDRESS
          echo Testing image URL using wget
          sleep 10
          wget -q -O - 127.0.0.1:5001/live | grep live

  terraform:
    name: terraform-deployment
    needs: [docker, code-coverage, unit_testing]
    runs-on: ubuntu-latest
    steps:
      - name: Checkout Repo
        uses: actions/checkout@v5

      - name: AWS Login
        uses: aws-actions/configure-aws-credentials@v4.3.1
        with:
          aws-access-key-id: ${{ secrets.AWS_ACCESS_KEY_ID }}
          aws-secret-access-key: ${{ secrets.AWS_SECRET_ACCESS_KEY }}
          aws-region: us-west-2

      - name: Setup Terraform
        uses: hashicorp/setup-terraform@v3.1.2
        with:
          terraform_version: 1.1.7

      - name: Terraform Init
        run: terraform init
        working-directory: ./Terraform

      - name: Terraform Plan
        run: terraform plan
        working-directory: ./Terraform

      - name: Terraform Apply or Destroy
        run: |
          if [ "${{ github.event.inputs.destroy }}" = "yes" ]; then
            terraform destroy -auto-approve
          else
            terraform apply -auto-approve
          fi
        working-directory: ./Terraform

  deploy:
    needs: terraform
    name: deploy to EKS
    runs-on: ubuntu-latest
    steps:
      - name: Checkout Config Files
        uses: actions/checkout@v5

      - name: Configure AWS Credentials
        uses: aws-actions/configure-aws-credentials@v4.3.1
        with:
          aws-access-key-id: ${{ secrets.AWS_ACCESS_KEY_ID }}
          aws-secret-access-key: ${{ secrets.AWS_SECRET_ACCESS_KEY }}
          aws-region: us-west-2

      - name: Update kubeconfig
        run: |
          aws eks --region us-west-2 update-kubeconfig --name stage-eks-cluster

      - name: Trigger App Deployment
        uses: statsig-io/kubectl-via-eksctl@main
        env:
          aws_access_key_id: ${{ secrets.AWS_ACCESS_KEY_ID }}
          aws_secret_access_key: ${{ secrets.AWS_SECRET_ACCESS_KEY }}
          region: us-west-2
          cluster: stage-eks-cluster

      - name: Deploy K8s Deployments
        run: |
          kubectl apply -f mongodb.yml
          kubectl apply -f deployment.yml
          kubectl apply -f service.yml
        working-directory: ./k8s

      - name: Verify Deployment
        run: |
          sleep 20
          kubectl get pods
          kubectl get svc
  deploy-monitoring:
        needs: deploy
        name: moitoring
        runs-on: ubuntu-latest
        env: 
          AWS_REGION: us-west-2
          EKS_CLUSTER_NAME: stage-eks-cluster
          GRAFANA_ADMIN_PASSWORD: ${{ secrets.grafana_admin_password }}

        steps:
            - name: checkout config files
              uses: actions/checkout@v5


            - name: Configure AWS Credentials
              uses: aws-actions/configure-aws-credentials@v4.3.1
              with:
                  aws-access-key-id: ${{ secrets.AWS_ACCESS_KEY_ID }}
                  aws-secret-access-key: ${{ secrets.AWS_SECRET_ACCESS_KEY }}
                  aws-region: us-west-2

            - name: update kubeconfig
              run: | 
                    aws eks --region us-west-2 update-kubeconfig --name stage-eks-cluster

            - name: Trigger app deployment
              uses: statsig-io/kubectl-via-eksctl@main
              env:
                 aws_access_key_id: ${{ secrets.AWS_ACCESS_KEY_ID }}
                 aws_secret_access_key: ${{ secrets.AWS_SECRET_ACCESS_KEY }}
                 region: us-west-2
                 cluster: stage-eks-cluster

            - name: Output monitoring namespace YAML
              run: kubectl create namespace monitoring --dry-run=client -o yaml
            - name: Create monitoring namespace
              run: kubectl create namespace monitoring || true

            - name: Add Helm repos
              run: |
                helm repo add prometheus-community https://prometheus-community.github.io/helm-charts
                helm repo add grafana https://grafana.github.io/helm-charts
                helm repo update
            - name: Render values with env
              run: |
               envsubst < values.yml > /tmp/values.rendered.yml
               echo "Rendered values:"
               tail -n +1 /tmp/values.rendered.yml
              working-directory: ./k8s
            - name: Cleanup stuck Helm releases
              run: |
                  if helm status kube-prometheus-stack -n monitoring | grep -q "pending"; then
                    echo "Cleaning up stuck release..."
                    helm uninstall kube-prometheus-stack -n monitoring || true
                  fi
              working-directory: ./k8s
              
            - name: Install/Upgrade kube-prometheus-stack
              run: |
                helm upgrade --install kube-prometheus-stack prometheus-community/kube-prometheus-stack \
                  --namespace monitoring \
                  --values /tmp/values.rendered.yml \
                  --wait --timeout 15m

            - name: Apply ServiceMonitor for my app
              run: |
                kubectl apply -f servicemonitor.yml
              working-directory: ./k8s

            - name: Show external endpoints
              run: |
                echo "Waiting for LoadBalancer IPs..."
                kubectl -n monitoring wait --for=condition=available deploy/kube-prometheus-stack-grafana --timeout=10m
                kubectl -n monitoring get svc -o wide
                echo "Grafana URL:"
                kubectl -n monitoring get svc kube-prometheus-stack-grafana -o jsonpath='{.status.loadBalancer.ingress[0].hostname}{"\n"}{.status.loadBalancer.ingress[0].ip}{"\n"}'
                echo "Prometheus URL:"
                kubectl -n monitoring get svc kube-prometheus-stack-prometheus -o jsonpath='{.status.loadBalancer.ingress[0].hostname}{"\n"}{.status.loadBalancer.ingress[0].ip}{"\n"}'
            